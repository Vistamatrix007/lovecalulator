<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Bikin Bootstrap Template - Index</title>
  <meta content="" name="description">
  <meta content="" name="keywords">



  <!-- Vendor CSS Files -->
  <link href="{{ asset('Bikin/assets/vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">
  <link href="{{ asset('Bikin/assets/vendor/boxicons/css/boxicons.min.css')}}" rel="stylesheet">
  <link href="{{ asset('Bikin/assets/vendor/owl.carousel/assets/owl.carousel.min.css')}}" rel="stylesheet">
  <link href="{{ asset('Bikin/assets/vendor/venobox/venobox.css')}}" rel="stylesheet">
  <link href="{{ asset('Bikin/assets/vendor/aos/aos.css')}}" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
  <!-- Template Main CSS File -->
  <link href="{{ asset('Bikin/assets/css/style.css')}}" rel="stylesheet">
  <!-- =======================================================
  * Template Name: Bikin - v2.2.1
  * Template URL: https://bootstrapmade.com/bikin-free-simple-landing-page-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->

  <style type="text/css">
  	.calculator {
  padding: 50px 50px 20px 50px;
  text-align: center;
  margin-left: 300px;
  margin-top: 100px;
  background-color:#211717;
  width: 50%;
}

.name-box {
  padding: 12px 14px;
  width: 60%;
}

/* buttons */
.buttons {
  color: #ffd7e8;
  background-color: #007bff80;
  border: solid;
  border-color: #ee4266;
  cursor: pointer;
  margin: 10px 10px;
  padding: 10px 20px 10px 20px;
  position: relative;
  opacity:1;
  font-size: 1rem;
}

.buttons:hover {
  box-shadow: 5px 3px #bd245f;
  opacity: 1;
  color: #ee4266;
}
/* Social Media  */
.social-media{ opacity:0.5;
  cursor:pointer;
  padding: 10px 3px 0 4px}
  .social-media:hover{opacity: 1;}
 a{color:#ee4266;}
 /* copy right  */
 p{opacity: 1;
 font-size: 1rem;}
 #notice{opacity: 0.5;
 font-size:.8rem;}
/* Media Query */
@media (max-width:600px) {
  .buttons{width:40%;}
  .calculator {width: 60%;
    padding: 10px 20px 10px 10px;
    margin-left: 100px;
    margin-top: 50px;
  }
}

.caluctarsec{
	 background-image: -webkit-linear-gradient(65deg, #007bff80 70%, #212121 30%);
  background-color: #c7004c;
  color: #007bff;
  font-family: 'Lobster', cursive;
}
div#Successtext {
    font-size: 28px;
    color: #dee2e6;
}

  </style>
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

      <h1 class="logo mr-auto"><a href="index.html">Gabbar is king</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo mr-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li class="active"><a href="index.html">Home</a></li>
          <li><a href="#about">About</a></li>
        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header><!-- End Header -->
  <!-- ======= Hero Section ======= -->
  <section class="caluctarsec">

  <div id="love-calculator" class="calculator">

    <form id="loveForm" id="loveform" class="" onsubmit="return loveValidation()" method="post">
      <div id="Welcometext">
      <h1>Welcome <i class="fas fa-heartbeat"></i></h1>
      <h2 id="lovefinal">Calculate your love score</h2>
      </div>
      <div id="Successtext">
      
      </div>
      <p>Please enter names below</p>
      <h2>Your Name</h2>
      <input id="name1" class="yourname name-box" type="text" placeholder="Your Name"></input>
      <h2>Lover's Name</h2>
      <input id="name2" class="lovername name-box" type="text" placeholder="Lover's Name"></input>
    </form>
    <button id="love-button" onclick="loveCalculator()" class="buttons" type="button"><i class="fas fa-heart"></i> Submit</button>
    <button class="buttons" type="submit"><i class="fas fa-heart-broken"></i> <a href="{{ url('/')}}">Reset</a></button>
    <footer>
      <a href="https://www.linkedin.com/in/tylerbakker35699864"><i class="social-media fab fa-1x fa-linkedin"></i></a>
      <a href="https://www.instagram.com/traizon_webdev/"><i class="social-media fab fa-1x fa-instagram"></i></a>
      <p id="notice">*Note:More updates coming soon!</p>

    </footer>
  </div>

  </section><!-- End Hero -->
  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>
  <div id="preloader"></div>

  <!-- The Modal -->
  <div class="modal fade" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Modal Heading</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
          Modal body..
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>

  <!-- Vendor JS Files -->
  <script src="{{ asset('Bikin/assets/vendor/jquery/jquery.min.js')}}"></script>
  <script src="{{ asset('Bikin/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
  <script src="{{ asset('Bikin/assets/vendor/jquery.easing/jquery.easing.min.js')}}"></script>
  <script src="{{ asset('Bikin/assets/vendor/php-email-form/validate.js')}}"></script>
  <script src="{{ asset('Bikin/assets/vendor/owl.carousel/owl.carousel.min.js')}}"></script>
  <script src="{{ asset('Bikin/assets/vendor/isotope-layout/isotope.pkgd.min.js')}}"></script>
  <script src="{{ asset('Bikin/assets/vendor/venobox/venobox.min.js')}}"></script>
  <script src="{{ asset('Bikin/assets/vendor/aos/aos.js')}}"></script>

  <!-- Template Main JS File -->
  <script src="{{ asset('Bikin/assets/js/main.js')}}"></script>

</body>

</html>


<script type="text/javascript">
  


 var loveCalculator=function () {

  var name1 = $("#name1").val();
  var name2 = $("#name2").val();

  const settings = {
  "async": true,
  "crossDomain": true,
  "url": "https://love-calculator.p.rapidapi.com/getPercentage?fname="+name1+"&sname="+name2,
  "method": "GET",
  "headers": {
    "x-rapidapi-key": "7a3410d8e7mshce6c0a5f0326331p11c4e2jsn909bf13d644a",
    "x-rapidapi-host": "love-calculator.p.rapidapi.com"
  }
};

$.ajax(settings).done(function (response) {
    console.log(response);
    var Percentage = response.percentage;
    var Result = response.result;
 $("#Successtext").html("<h4>Percentage of love between</h4><h3 id='lovefinal'>You & Your <i class='fas fa-heartbeat'></i> Partner is</h3>"+Percentage+"%"+"<br>"+Result);
 $("#Welcometext").hide();
}); 


  if (yourName === "") {
    alert("please enter your name");
  } else if (loversName === "") {
    alert("Please enter your lovers name");

  } else if (isNotClicked) {
    document.getElementById("lovefinal").innerHTML = yourName + " and " + loversName + " your lovescore is " + loveFinal + " % ";
    isNotclicked=false;
  }
  else {
    document.getElementById("lovefinal").innerHTML = yourName + " and " + loversName + " your lovescore is " + loveFinal + " % ";
  }
};

//resetbutton
function resetFunction() {
  location.reload();
}




</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>